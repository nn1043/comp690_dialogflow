Wildcats_Help Agent last modified 12/18/20.

To import this Agent:
1. Create a Dialogflow Agent.
2. Go to settings on the top-left, next to the Agent name.
3. Find the ‘Export and Import’ tab, and click ‘Import from ZIP.’
4. Create a ZIP file that excludes this readme and upload it.